<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8" />
        <title>Form Wizard - Ace Admin</title>

        <meta name="description" content="and Validation" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

        <!-- bootstrap & fontawesome -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

        <!-- page specific plugin styles -->
        <link rel="stylesheet" href="assets/css/select2.min.css" />

        <!-- text fonts -->
        <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

        <!-- ace styles -->
        <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

        <!--[if lte IE 9]>
                <link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
        <![endif]-->
        <link rel="stylesheet" href="assets/css/ace-skins.min.css" />
        <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

        <!--[if lte IE 9]>
          <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
        <![endif]-->

        <!-- inline styles related to this page -->

        <!-- ace settings handler -->
        <script src="assets/js/ace-extra.min.js"></script>

        <!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

        <!--[if lte IE 8]>
        <script src="assets/js/html5shiv.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <?php
        $host = "localhost";
        $user = "hitrac";
        $password = "hitrac";
        $database = "house";

        $connection = mysqli_connect($host, $user, $password, $database) or die("Error in database connection");
         if(isset($_POST['zvaita'])){
             echo 'hello';
                      }
        if (isset($_POST['save'])) {
            $firstName = $_POST['firstName'];
            $lastName = $_POST['lastName'];
            $gender = $_POST['gender'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            $owner = "INSERT INTO owner VALUES(' ','$firstName','$lastName','$gender','$phone','$address','')";
            $dataPost = mysqli_query($connection, $owner);
            if ($dataPost) {
                ?>
                <script type="text/javascript">
                    alert('Data saved Successfully');
                    window.location.href = 'wizard.php';
                </script>
                <?php
            } else {
                echo mysqli_error($connection);
                ?>
                <script type="text/javascript">
                    alert('error occured while updating data');
                </script>
                <?php
            }
        }
        ?>


        <div class="widget-box">
            <div class="widget-header widget-header-blue widget-header-flat">
                <h4 class="widget-title lighter">Add Listing (Add Property)</h4>
            </div>
            <div class="widget-body">
                <div class="widget-main">
                    <div id="fuelux-wizard-container">
                        <div>
                            <ul class="steps">
                                <li data-step="1" class="active">
                                    <span class="step">1</span>
                                    <span class="title">Personal Information</span>
                                </li>

                                <li data-step="2">
                                    <span class="step">2</span>
                                    <span class="title">Property Information</span>
                                </li>

                                <li data-step="3">
                                    <span class="step">3</span>
                                    <span class="title">Other Information</span>
                                </li>

                                <li data-step="4">
                                    <span class="step">4</span>
                                    <span class="title">Other Info</span>
                                </li>
                            </ul>
                        </div>

                        <hr />

                        <div class="step-content pos-rel">
                            <div class="step-pane active" data-step="1">
                                <h3 class="lighter block green">Enter the following personal information</h3>


                                <form class="form-horizontal " id="validation-form" method="POST" >
                                    <div class="form-group">
                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="firstName">First Name: *</label>

                                        <div class="col-xs-12 col-sm-9">
                                            <div class="clearfix">
                                                <input type="text" name="firstName" id="firstName" required="" class="col-xs-12 col-sm-4"  data-toggle="popover" data-trigger="hover" data-placement="right"
                                                       data-content="Enter your birth name. The first name you were given when you were" />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="space-2"></div>

                                    <div class="form-group">
                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="lastName">Last Name: *</label>

                                        <div class="col-xs-12 col-sm-9">
                                            <div class="clearfix">
                                                <input type="text" name="lastName" id="lastName" required="" class="col-xs-12 col-sm-4" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right">Gender</label>

                                        <div class="col-xs-12 col-sm-9">
                                            <div>
                                                <label class="line-height-1 blue">
                                                    <input name="gender" value="male" type="radio" class="ace" />
                                                    <span class="lbl"> Male</span>
                                                </label>
                                            </div>

                                            <div>
                                                <label class="line-height-1 blue">
                                                    <input name="gender" value="female" type="radio" class="ace" />
                                                    <span class="lbl"> Female</span>
                                                </label>
                                            </div>
                                            <div>
                                                <label class="line-height-1 blue">
                                                    <input name="gender" value="others" type="radio" class="ace" />
                                                    <span class="lbl"> Others</span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="address">Postal Address: *</label>

                                        <div class="col-xs-12 col-sm-9">
                                            <div class="clearfix">
                                                <textarea cols="55" required="" name="address" id="address"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="hr hr-dotted"></div>

                                    <div class="form-group">
                                        <label class="control-label col-xs-12 col-sm-3 no-padding-right" for="phone">Phone Number: *</label>

                                        <div class="col-xs-12 col-sm-9">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="ace-icon fa fa-phone"></i>
                                                </span>

                                                <input type="tel" id="phone" name="phone" class="col-xs-12 col-sm-4" />
                                            </div>
                                        </div>
                                    </div>


                                    <div class="hr hr-dotted"></div>

                                    <button class="btn btn-success  btn-lg" type="submit" name="save" >Save and Continue
                                    </button>

                                </form>
                            </div>

                            <div class="step-pane" data-step="2" id="step2">
                                <div class="col-sm-12">
                                    <form method="POST" >
                                        <div class="col-sm-4">
                                            <div class="widget-box">
                                                <div class="widget-body">
                                                    <div class="widget-main">

                                                        <div class="form-group">
                                                            <div class="col-xs-12">
                                                                <input multiple="" type="file" id="id-input-file-3" />
                                                            </div>
                                                        </div>

                                                        <label>
                                                            <input type="checkbox" name="file-format" id="id-file-format" class="ace" />
                                                            <span class="lbl"> Allow only images</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    <button class="btn btn-success  btn-lg" type="submit" name="property" >Save and Continue</button>
                                 </form>
                                </div>
                            </div>
                            <div class="step-pane" data-step="3">
                                <div class="center">
                                    <h3 class="blue lighter">This is step 3</h3>
                                </div>
                            </div>

                            <div class="step-pane" data-step="4">
                                <div class="center">
                                    <h3 class="green">Congrats!</h3>
                                    Your product is ready to ship! Click finish to continue!
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr />
                    <div class="wizard-actions">
                        <button class="btn btn-prev">
                            <i class="ace-icon fa fa-arrow-left"></i>
                            Prev
                        </button>

                        <button class="btn btn-success btn-next" data-last="Finish">
                            Next
                            <i class="ace-icon fa fa-arrow-right icon-on-right"></i>
                        </button>
                    </div>

                </div><!-- /.widget-main -->

            </div><!-- /.widget-body -->
        </div>

        <!-- basic scripts -->

        <!--[if !IE]> -->
        <script src="assets/js/jquery-2.1.4.min.js"></script>

        <!-- <![endif]-->

        <!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
        <script type="text/javascript">
                    if ('ontouchstart' in document.documentElement)
                        document.write("<script src='assets/js/jquery.mobile.custom.min.js'>" + "<" + "/script>");
        </script>
        <script src="assets/js/bootstrap.min.js"></script>

        <!-- page specific plugin scripts -->
        <script src="assets/js/wizard.min.js"></script>
        <script src="assets/js/jquery.validate.min.js"></script>
        <script src="assets/js/jquery-additional-methods.min.js"></script>
        <script src="assets/js/bootbox.js"></script>
        <script src="assets/js/jquery.maskedinput.min.js"></script>
        <script src="assets/js/select2.min.js"></script>

        <!-- ace scripts -->
        <script src="assets/js/ace-elements.min.js"></script>
        <script src="assets/js/ace.min.js"></script>
        <script>
                    $(document).ready(function () {
                        $('[data-toggle="popover"]').popover();
                    });
        </script>
        <!-- inline scripts related to this page -->
        <script type="text/javascript">
            jQuery(function ($) {

                $('[data-rel=tooltip]').tooltip();

                $('.select2').css('width', '200px').select2({allowClear: true})
                        .on('change', function () {
                            $(this).closest('form').validate().element($(this));
                        });


                var $validation = false;
                $('#fuelux-wizard-container')
                        .ace_wizard({
                            //step: 2 //optional argument. wizard will jump to step "2" at first
                            //buttons: '.wizard-actions:eq(0)'
                        })
                        .on('actionclicked.fu.wizard', function (e, info) {
                            if (info.step == 1 && $validation) {
                                if (!$('#validation-form').valid())
                                    e.preventDefault();
                            }
                        })
                        //.on('changed.fu.wizard', function() {
                        //})
                        .on('finished.fu.wizard', function (e) {
                            bootbox.dialog({
                                message: "Thank you! Your information was successfully saved!",
                                buttons: {
                                    "success": {
                                        "label": "OK",, "name":"zvaita",
                                        "className": "btn-sm btn-primary"
                                    }
                                }
                            });
                        }).on('stepclick.fu.wizard', function (e) {
                    //e.preventDefault();//this will prevent clicking and selecting steps
                });


                //jump to a step
                /**
                 var wizard = $('#fuelux-wizard-container').data('fu.wizard')
                 wizard.currentStep = 3;
                 wizard.setState();
                 */

                //determine selected step
                //wizard.selectedItem().step



                //hide or show the other form which requires validation
                //this is for demo only, you usullay want just one form in your application
                $('#skip-validation').removeAttr('checked').on('click', function () {
                    $validation = this.checked;
                    if (this.checked) {
                        $('#sample-form').hide();
                        $('#validation-form').removeClass('hide');
                    }
                })



                //documentation : http://docs.jquery.com/Plugins/Validation/validate



                $('#validation-form').validate({
                    errorElement: 'div',
                    errorClass: 'help-block',
                    focusInvalid: false,
                    ignore: "",
                    rules: {
                        email: {
                            required: true,
                            email: true
                        },
                        password: {
                            required: true,
                            minlength: 5
                        },
                        password2: {
                            required: true,
                            minlength: 5,
                            equalTo: "#password"
                        },
                        name: {
                            required: true
                        },
                        phone: {
                            required: true,
                            phone: 'required'
                        },
                        url: {
                            required: true,
                            url: true
                        },
                        comment: {
                            required: true
                        },
                        state: {
                            required: true
                        },
                        platform: {
                            required: true
                        },
                        subscription: {
                            required: true
                        },
                        gender: {
                            required: true,
                        },
                        agree: {
                            required: true,
                        }
                    },

                    messages: {
                        email: {
                            required: "Please provide a valid email.",
                            email: "Please provide a valid email."
                        },
                        password: {
                            required: "Please specify a password.",
                            minlength: "Please specify a secure password."
                        },
                        state: "Please choose state",
                        subscription: "Please choose at least one option",
                        gender: "Please choose gender",
                        agree: "Please accept our policy"
                    },

                    highlight: function (e) {
                        $(e).closest('.form-group').removeClass('has-info').addClass('has-error');
                    },

                    success: function (e) {
                        $(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
                        $(e).remove();
                    },

                    errorPlacement: function (error, element) {
                        if (element.is('input[type=checkbox]') || element.is('input[type=radio]')) {
                            var controls = element.closest('div[class*="col-"]');
                            if (controls.find(':checkbox,:radio').length > 1)
                                controls.append(error);
                            else
                                error.insertAfter(element.nextAll('.lbl:eq(0)').eq(0));
                        } else if (element.is('.select2')) {
                            error.insertAfter(element.siblings('[class*="select2-container"]:eq(0)'));
                        } else if (element.is('.chosen-select')) {
                            error.insertAfter(element.siblings('[class*="chosen-container"]:eq(0)'));
                        } else
                            error.insertAfter(element.parent());
                    },

                    submitHandler: function (form) {
                    },
                    invalidHandler: function (form) {
                    }
                });




                $('#modal-wizard-container').ace_wizard();
                $('#modal-wizard .wizard-actions .btn[data-dismiss=modal]').removeAttr('disabled');


                /**
                 $('#date').datepicker({autoclose:true}).on('changeDate', function(ev) {
                 $(this).closest('form').validate().element($(this));
                 });
                 
                 $('#mychosen').chosen().on('change', function(ev) {
                 $(this).closest('form').validate().element($(this));
                 });
                 */


                $(document).one('ajaxloadstart.page', function (e) {
                    //in ajax mode, remove remaining elements before leaving page
                    $('[class*=select2]').remove();
                });

                $('#id-input-file-1 , #id-input-file-2').ace_file_input({
                    no_file: 'No File ...',
                    btn_choose: 'Choose',
                    btn_change: 'Change',
                    droppable: false,
                    onchange: null,
                    thumbnail: false //| true | large
                            //whitelist:'gif|png|jpg|jpeg'
                            //blacklist:'exe|php'
                            //onchange:''
                            //
                });
                //pre-show a file name, for example a previously selected file
                //$('#id-input-file-1').ace_file_input('show_file_list', ['myfile.txt'])


                $('#id-input-file-3').ace_file_input({
                    style: 'well',
                    btn_choose: 'Drop files here or click to choose',
                    btn_change: null,
                    no_icon: 'ace-icon fa fa-cloud-upload',
                    droppable: true,
                    thumbnail: 'small'//large | fit
                            //,icon_remove:null//set null, to hide remove/reset button
                            /**,before_change:function(files, dropped) {
                             //Check an example below
                             //or examples/file-upload.html
                             return true;
                             }*/
                            /**,before_remove : function() {
                             return true;
                             }*/
                    ,
                    preview_error: function (filename, error_code) {
                        //name of the file that failed
                        //error_code values
                        //1 = 'FILE_LOAD_FAILED',
                        //2 = 'IMAGE_LOAD_FAILED',
                        //3 = 'THUMBNAIL_FAILED'
                        //alert(error_code);
                    }

                }).on('change', function () {
                    //console.log($(this).data('ace_input_files'));
                    //console.log($(this).data('ace_input_method'));
                });


                //$('#id-input-file-3')
                //.ace_file_input('show_file_list', [
                //{type: 'image', name: 'name of image', path: 'http://path/to/image/for/preview'},
                //{type: 'file', name: 'hello.txt'}
                //]);




                //dynamically change allowed formats by changing allowExt && allowMime function
                $('#id-file-format').removeAttr('checked').on('change', function () {
                    var whitelist_ext, whitelist_mime;
                    var btn_choose
                    var no_icon
                    if (this.checked) {
                        btn_choose = "Drop images here or click to choose";
                        no_icon = "ace-icon fa fa-picture-o";

                        whitelist_ext = ["jpeg", "jpg", "png", "gif", "bmp"];
                        whitelist_mime = ["image/jpg", "image/jpeg", "image/png", "image/gif", "image/bmp"];
                    } else {
                        btn_choose = "Drop files here or click to choose";
                        no_icon = "ace-icon fa fa-cloud-upload";

                        whitelist_ext = null;//all extensions are acceptable
                        whitelist_mime = null;//all mimes are acceptable
                    }
                    var file_input = $('#id-input-file-3');
                    file_input
                            .ace_file_input('update_settings',
                                    {
                                        'btn_choose': btn_choose,
                                        'no_icon': no_icon,
                                        'allowExt': whitelist_ext,
                                        'allowMime': whitelist_mime
                                    })
                    file_input.ace_file_input('reset_input');

                    file_input
                            .off('file.error.ace')
                            .on('file.error.ace', function (e, info) {
                                //console.log(info.file_count);//number of selected files
                                //console.log(info.invalid_count);//number of invalid files
                                //console.log(info.error_list);//a list of errors in the following format

                                //info.error_count['ext']
                                //info.error_count['mime']
                                //info.error_count['size']

                                //info.error_list['ext']  = [list of file names with invalid extension]
                                //info.error_list['mime'] = [list of file names with invalid mimetype]
                                //info.error_list['size'] = [list of file names with invalid size]


                                /**
                                 if( !info.dropped ) {
                                 //perhapse reset file field if files have been selected, and there are invalid files among them
                                 //when files are dropped, only valid files will be added to our file array
                                 e.preventDefault();//it will rest input
                                 }
                                 */


                                //if files have been selected (not dropped), you can choose to reset input
                                //because browser keeps all selected files anyway and this cannot be changed
                                //we can only reset file field to become empty again
                                //on any case you still should check files with your server side script
                                //because any arbitrary file can be uploaded by user and it's not safe to rely on browser-side measures
                            });


                    /**
                     file_input
                     .off('file.preview.ace')
                     .on('file.preview.ace', function(e, info) {
                     console.log(info.file.width);
                     console.log(info.file.height);
                     e.preventDefault();//to prevent preview
                     });
                     */

                });
            })
        </script>
    </body>
</html>
