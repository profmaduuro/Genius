<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include 'dbConfig.php';
        if (isset($_POST['btn-upload'])) {

            $file = rand(100, 100000) . "-" . $_FILES['file']['name'];
            $file_loc = $_FILES['file']['tmp_name'];
            $file_size = $_FILES['file']['size'];
            $file_type = $_FILES['file']['type'];
            $folder = "uploads/";

            // new file size in KB
            $new_size = $file_size / 1024;
            // new file size in KB
            // make file name in lower case
            $new_file_name = strtolower($file);
            // make file name in lower case

            $final_file = str_replace(' ', '-', $new_file_name);
            $requestStatus=0;
            if (move_uploaded_file($file_loc, $folder . basename($final_file))) {
                $sql = "INSERT INTO tbl_uploads(file,type,size,requeststatus) VALUES('$final_file','$file_type','$new_size','$requestStatus')";
                mysqli_query($connect, $sql);
                ?>
                <script>
                    alert('successfully uploaded');
                    window.location.href = 'files.php?success';
                </script>
                <?php
            } else {
                ?>
                <script>
                    alert('error while uploading file');
                    window.location.href = 'files.php?fail';
                </script>
                <?php
            }
        }
        ?>
    </body>
</html>
