<!DOCTYPE html>
<html lang="en">

    <?php
    include './header.php';
    ?>
    <!-- Property start from here -->
    <section class="at-property-sec at-property-right-sidebar" style="margin-top:-80px">
        <div class="container-fluid">
            <div class="row">
                <div class="alert alert-warning" > <h4>Property Description</h4></div>
                <div class="col-md-7">
                    <div class="at-property-details-col">
                        <div id="myCarousel" class="carousel slide" data-ride="carousel">
                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <a href='images/slider/slider-1.jpg' target="_"><img src="images/slider/slider-1.jpg"  alt=""></a>
                                    <div class="carousel-caption">
                                        <h2>NEW SUPERB VILLA</h2>
                                    </div>
                                </div>
                                <!-- End Item -->
                                <div class="item">
                                    <a href='images/slider/slider-2.jpg' target="_"><img src="images/slider/slider-2.jpg" alt=""></a>
                                    <div class="carousel-caption">
                                        <h2>nice guest room</h2>
                                    </div>
                                </div>
                                <!-- End Item -->
                                <div class="item">
                                    <a href='images/slider/slider-3.jpg' target="_"><img src="images/slider/slider-3.jpg" alt=""></a>
                                    <div class="carousel-caption">
                                        <h2>Well bathroom</h2>
                                    </div>
                                </div>
                                <!-- End Item -->
                                <div class="item">
                                    <a href='images/slider/slider-4.jpg' target="_"> <img src="images/slider/slider-4.jpg" alt=""></a>
                                    <div class="carousel-caption">
                                        <h2>awesome bedroom</h2>
                                    </div>
                                </div>
                                <!-- End Item -->
                            </div>
                            <!-- End Carousel Inner -->
                            <ul class="nav nav-pills nav-justified">
                                <li data-target="#myCarousel" data-slide-to="0" class="active">
                                    <a href="#"><img src="images/slider/slider-1.jpg" alt="">
                                    </a>
                                </li>
                                <li data-target="#myCarousel" data-slide-to="1">
                                    <a href="#"><img src="images/slider/slider-2.jpg" alt="">
                                    </a>
                                </li>
                                <li data-target="#myCarousel" data-slide-to="2">
                                    <a href="#"><img src="images/slider/slider-3.jpg" alt="">
                                    </a>
                                </li>
                                <li data-target="#myCarousel" data-slide-to="3">
                                    <a href="#"><img src="images/slider/slider-4.jpg" alt="">
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!-- End Carousel -->
                        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. </p>
                        <div class="at-sec-title at-sec-title-left">
                            <h2>Property <span>Features</span></h2>
                            <div class="at-heading-under-line">
                                <div class="at-heading-inside-line"></div>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum totam et dolores voluptatem porro tempore temporibus ducimus</p>
                        </div>
                        <div class="row at-property-features">
                            <div class="col-md-6 clearfix">
                                <ul>
                                    <li>Property ID : <span class="pull-right">AB-010234</span>
                                    </li>
                                    <li>Full Area : <span class="pull-right">520 sqft</span>
                                    </li>
                                    <li>Bedrooms : <span class="pull-right">6</span>
                                    </li>
                                    <li>Bathrooms : <span class="pull-right">3</span>
                                    </li>
                                    <li>Garages : <span class="pull-right">1</span>
                                    </li>
                                    <li>swimming pool : <span class="pull-right">Yes</span>
                                    </li>
                                    <li>Party Rooms : <span class="pull-right">Yes</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li>Status : <span class="pull-right"> for Sale</span>
                                    </li>
                                    <li>Kitchen : <span class="pull-right">2</span>
                                    </li>
                                    <li>AC Rooms: <span class="pull-right">4</span>
                                    </li>
                                    <li>Internet : <span class="pull-right">Yes</span>
                                    </li>
                                    <li>Cable TV : <span class="pull-right">Yes</span>
                                    </li>
                                    <li>Balcony : <span class="pull-right">Yes</span>
                                    </li>
                                    <li>Pool : <span class="pull-right">Yes</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="at-sidebar at-col-default-mar">
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                        <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyC9uevjs7cQZS7hzUkkFUu-i9VWq5qw9eM'></script>
                                        <div style='overflow:hidden;height:400px;'><div id='gmap_canvas' style='height:400px;'></div>
                                            <style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> 


                                        <script type='text/javascript'>
                                            function init_map() {
                                                var myOptions = {zoom: 17, center: new google.maps.LatLng(-17.8276402, 31.0640321), mapTypeId: google.maps.MapTypeId.HYBRID};
                                                map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
                                                marker = new google.maps.Marker({map: map, position: new google.maps.LatLng(-17.8276402, 31.0640321)});
                                                infowindow = new google.maps.InfoWindow({content: '<strong>Mac Homes</strong><br>27 Frank Johnson Avenue Eastlea<br> Harare<br>'});
                                                google.maps.event.addListener(marker, 'click', function () {
                                                    infowindow.open(map, marker);
                                                });
                                                infowindow.open(map, marker);
                                            }
                                            google.maps.event.addDomListener(window, 'load', init_map);


                                        </script>

                            </div>
                        </div>

                        <br/><br/>
                        <!-- Inner page heading end -->
                        <div class="at-latest-news">
                            <h3 class="at-sedebar-title">Other Houses</h3>
                            <!-- Property start from here -->
                            <section class="at-property-sec" style="margin-top: -100px">

                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="at-property-item at-col-default-mar">
                                            <div class="at-property-img">
                                                <img src="images/property/1.jpg" alt="">
                                                <div class="at-property-overlayer"></div>
                                                <a class="btn btn-default at-property-btn" href="propertydetails.php" role="button">View Details</a>
                                                <h4>For Sale</h4>
                                                <h5>$59,999</h5>
                                            </div>
                                            <div class="at-property-dis">
                                                <ul>
                                                    <li><i class="fa fa-object-group" aria-hidden="true"></i> 520 sq ft</li>
                                                    <li><i class="fa fa-bed" aria-hidden="true"></i> 6</li>
                                                    <li><i class="fa fa-bath" aria-hidden="true"></i> 3</li>
                                                </ul>
                                            </div>
                                            <div class="at-property-location">
                                                <h4><i class="fa fa-home" aria-hidden="true"></i><a href="propertydetails.php">New Superb Villa</a></h4>
                                                <p><i class="fa fa-map-marker" aria-hidden="true"></i> 12/1 main Road, Summit, New York</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="at-property-item at-col-default-mar">
                                            <div class="at-property-img">
                                                <img src="images/property/2.jpg" alt="">
                                                <div class="at-property-overlayer"></div>
                                                <a class="btn btn-default at-property-btn" href="propertydetails.php" role="button">View Details</a>
                                                <h4 class="at-bg-black">For Rent</h4>
                                                <h5 class="at-bg-black">$59,999</h5>
                                            </div>
                                            <div class="at-property-dis">
                                                <ul>
                                                    <li><i class="fa fa-object-group" aria-hidden="true"></i> 520 sq ft</li>
                                                    <li><i class="fa fa-bed" aria-hidden="true"></i> 6</li>
                                                    <li><i class="fa fa-bath" aria-hidden="true"></i> 3</li>
                                                </ul>
                                            </div>
                                            <div class="at-property-location">
                                                <h4><i class="fa fa-home" aria-hidden="true"></i><a href="propertydetails.php">New Superb Villa</a></h4>
                                                <p><i class="fa fa-map-marker" aria-hidden="true"></i> 12/1 main Road, Summit, New York</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="at-property-item at-col-default-mar">
                                            <div class="at-property-img">
                                                <img src="images/property/3.jpg" alt="">
                                                <div class="at-property-overlayer"></div>
                                                <a class="btn btn-default at-property-btn" href="propertydetails.php" role="button">View Details</a>
                                                <h4>For Sale</h4>
                                                <h5>$59,999</h5>
                                            </div>
                                            <div class="at-property-dis">
                                                <ul>
                                                    <li><i class="fa fa-object-group" aria-hidden="true"></i> 520 sq ft</li>
                                                    <li><i class="fa fa-bed" aria-hidden="true"></i> 6</li>
                                                    <li><i class="fa fa-bath" aria-hidden="true"></i> 3</li>
                                                </ul>
                                            </div>
                                            <div class="at-property-location">
                                                <h4><i class="fa fa-home" aria-hidden="true"></i><a href="propertydetails.php">New Superb Villa</a></h4>
                                                <p><i class="fa fa-map-marker" aria-hidden="true"></i> 12/1 main Road, Summit, New York</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="at-property-item at-col-default-mar">
                                            <div class="at-property-img">
                                                <img src="images/property/4.jpg" alt="">
                                                <div class="at-property-overlayer"></div>
                                                <a class="btn btn-default at-property-btn" href="propertydetails.php" role="button">View Details</a>
                                                <h4 class="at-bg-black">For Rent</h4>
                                                <h5 class="at-bg-black">$59,999</h5>
                                            </div>
                                            <div class="at-property-dis">
                                                <ul>
                                                    <li><i class="fa fa-object-group" aria-hidden="true"></i> 520 sq ft</li>
                                                    <li><i class="fa fa-bed" aria-hidden="true"></i> 6</li>
                                                    <li><i class="fa fa-bath" aria-hidden="true"></i> 3</li>
                                                </ul>
                                            </div>
                                            <div class="at-property-location">
                                                <h4><i class="fa fa-home" aria-hidden="true"></i><a href="propertydetails.php">New Superb Villa</a></h4>
                                                <p><i class="fa fa-map-marker" aria-hidden="true"></i> 12/1 main Road, Summit, New York</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="at-property-item at-col-default-mar">
                                            <div class="at-property-img">
                                                <img src="images/property/5.jpg" alt="">
                                                <div class="at-property-overlayer"></div>
                                                <a class="btn btn-default at-property-btn" href="propertydetails.php" role="button">View Details</a>
                                                <h4>For Sale</h4>
                                                <h5>$59,999</h5>
                                            </div>
                                            <div class="at-property-dis">
                                                <ul>
                                                    <li><i class="fa fa-object-group" aria-hidden="true"></i> 520 sq ft</li>
                                                    <li><i class="fa fa-bed" aria-hidden="true"></i> 6</li>
                                                    <li><i class="fa fa-bath" aria-hidden="true"></i> 3</li>
                                                </ul>
                                            </div>
                                            <div class="at-property-location">
                                                <h4><i class="fa fa-home" aria-hidden="true"></i><a href="propertydetails.php">New Superb Villa</a></h4>
                                                <p><i class="fa fa-map-marker" aria-hidden="true"></i> 12/1 main Road, Summit, New York</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="at-pagination">
                                        <ul class="pagination">
                                            <li><a href="#"><i class="fa fa-angle-double-left" aria-hidden="true"></i></a>
                                            </li>
                                            <li><a href="#">1</a>
                                            </li>
                                            <li><a href="#">2</a>
                                            </li>
                                            <li><a href="#">3</a>
                                            </li>
                                            <li><a href="#">4</a>
                                            </li>
                                            <li><a href="#">5</a>
                                            </li>
                                            <li><a href="#"><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                                            </li>
                                        </ul>
                                    </div>

                            </section>
                            <!-- Property End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Property End -->

    <?php
    include './footer.php';
    ?>
</html>