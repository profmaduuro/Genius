<?php

$host="localhost";
$user="root";
$password="";
$database="home";
$connect = mysqli_connect($host, $user, $password, $database);

