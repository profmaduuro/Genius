<?php
include './config/db.php';
if(isset($_POST['Comment'])){
 $fullname=$_POST['name'];   
 $email=$_POST['email']; 
 $comment=$_POST['message']; 
 
 
 $sql = "INSERT INTO comments VALUES('','$fullname','$email','$comment')";
 if(mysqli_query($connect, $sql)){
     
   ?>
                <script type="text/javascript">
                    alert('Successfully Placed a comment');
                    window.location.href = 'contact.php';
                </script>


                <?php
    
}else {
                ?>
                <script type="text/javascript">
                    alert('error occure while placing a comment');
                    window.location.href = 'contact.php';
                </script>
                <?php
            }
}


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Homes | Contact Us</title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <script type="text/javascript">
            //<![CDATA[
            try {
                if (!window.CloudFlare) {
                    var CloudFlare = [{verbose: 0, p: 0, byc: 0, owlid: "cf", bag2: 1, mirage2: 0, oracle: 0, paths: {cloudflare: "/cdn-cgi/nexp/dok3v=1613a3a185/"}, atok: "dab54c9f2269d3daa19f1ddfe5efec5f", petok: "cb72b81ea40eb06896581684260e510c3c546020-1465050552-1800", zone: "hitrac.co.zw", rocket: "0", apps: {"vuukle": {"domain_id": "10690396", "account_id": "65983", "comments-location": "left"}, "abetterbrowser": {"ie": "6"}}, sha2test: 0}];
                    !function (a, b) {
                        a = document.createElement("script"), b = document.getElementsByTagName("script")[0], a.async = !0, a.src = "../../ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3de982913d31/cloudflare.min.js", b.parentNode.insertBefore(a, b)
                    }()
                }
            } catch (e) {
            }
            ;
            //]]>
        </script>
        <link rel="shortcut icon" href="./images/icon.ico">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=PT+Serif' rel='stylesheet' type='text/css'>
        <link href="./bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="./bootstrap/fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="./404.html" rel="stylesheet">
        <link href="./bootstrap/fonts/fontello/css/fontello.css" rel="stylesheet">
        <link href="./404.html" rel="stylesheet">
        <link href="./bootstrap/css/magnific-popup.css" rel="stylesheet">
        <link href="./bootstrap/css/settings.css" rel="stylesheet">
        <link href="./bootstrap/css/animations.css" rel="stylesheet">
        <link href="./bootstrap/css/owl.carousel.css" rel="stylesheet">
        <link href="./bootstrap/css/owl.transitions.css" rel="stylesheet">
        <link href="./bootstrap/css/hover-min.css" rel="stylesheet">
        <link href="./bootstrap/css/sweetalert.css" rel="stylesheet">
        <link href="bootstrap/css/w3.css" rel="stylesheet">
        <link href="./bootstrap/css/style.css" rel="stylesheet" >
        <link href="./bootstrap/css/light_blue.css" rel="stylesheet">
        <link href="./bootstrap/css/custom.css" rel="stylesheet">
    </head>
    <body class="no-trans front-page transparent-header  ">

        <!-- header-container end -->
        <!-- ================ -->
        <div class="banner dark-translucent-bg" style="background-image:url(./images/page-banner.png); background-position: 50% 32%;">
            <!-- breadcrumb start -->
            <!-- ================ -->
            <div class="breadcrumb-container">
                <div class="container">
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home pr-10"></i><a class="link-dark" href="index.html">Home</a></li>
                        <li class="active">Contact Us</li>
                    </ol>
                </div>
            </div>
            <!-- breadcrumb end -->
            <div class="container">
                <div class="row">
                    <div class="col-md-8 text-center col-md-offset-2 pv-20">
                        <h1 class="page-title text-center">Contact Us</h1>
                        <div class="separator"></div>

                    </div>
                </div>
            </div>
        </div>
        <!-- banner end -->

        <!-- main-container start -->
        <!-- ================ -->
        <section class="main-container">

            <div class="container">
                <div class="row">

                    <!-- ================ -->
                    <div class="main col-md-12 space-bottom">
                        <h2 class="title">Place your comment</h2>
                        <div class="row">
                            <div class="col-md-6">

                                <div class="alert alert-success hidden" id="MessageSent">
                                    We have received your message, we will contact you very soon.
                                </div>
                                <div class="alert alert-danger hidden" id="MessageNotSent">
                                    Oops! Something went wrong please refresh the page and try again.
                                </div>
                                <div>
                                    <?php
                                    global $message;
                                    echo $message;
                                    ?></div>
                                <div class="contact-form">
                                    <form method="post"  >
                                        <div class="form-group has-feedback">
                                            <label for="name">Name*</label>
                                            <input type="text" class="form-control" id="name" name="name" required="required" placeholder="Full Name"/>
                                            <i class="fa fa-user form-control-feedback"></i>
                                        </div>
                                        <div class="form-group has-feedback">
                                            <label for="email">Email*</label>
                                            <input type="email" class="form-control" id="email" name="email" placeholder="Email"/>
                                            <i class="fa fa-envelope form-control-feedback"></i>
                                        </div>
                                        <div class="form-group has-feedback">
                                            <label for="message">Message*</label>
                                            <textarea class="form-control" rows="6" id="message" name="message" placeholder="Your Massage" required=""></textarea>
                                            <i class="fa fa-pencil form-control-feedback"></i>
                                        </div>
                                        <button  type="submit" name="Comment" class="w3-btn w3-btn-block w3-white w3-border w3-border-blue w3-round">Submit</button>
                                    </form>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div id="map-canvas">

                                    <!-- ===================start side contact============= -->

                                    <div class="row" style="margin-left:30%">

                                        <!-- main start -->
                                        <!-- ================ -->
                                        <div class="main col-md-12 space-bottom">

                                        </div>
                                        <table border="0"  >
                                            <tr><td><h2 class="title"><b>Physical Address</b></h2></td></tr>
                                            <tr>
                                                <td><h4>Hse Number 6108</h4></td>
                                            </tr>
                                            <tr>
                                                <td><h4>Budiriro 5B,</h4></td>
                                            </tr>

                                            <tr>
                                                <td><h4>Harare, Zimbabwe</h4></td>
                                            </tr>
                                            <tr>
                                                <td><h2></h2></td>
                                            </tr>
                                            <tr>
                                                <td><h2 class="title"><b>Contact Details</b></h2></td>
                                            </tr>
                                            <tr>
                                                <td><h4>+263 775 686 925,<br/> +263 774 438 660,<br/> +263 772 404 089</h4></td>
                                            </tr>

                                            <tr><td><h4>Email: profmaduuro@gmail.com</h4></td></tr>
                                        </table>



                                        <!-- main end -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ===================end start ==================== -->



            </div>

            <!-- main end -->



        </section>
        <!-- main-container end -->
        <section class="container">
            <div class="row">
                <h3 class="w3-btn-block w3-light-blue w3-round">Our location on the map</h3>
                <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyC9uevjs7cQZS7hzUkkFUu-i9VWq5qw9eM'></script>
                <div style='overflow:hidden;height:400px;width:1190px;'><div id='gmap_canvas' style='height:400px;width:1190px;'></div>
                    <style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> 
                <a href='https://add-map.org/'>embed google maps in wordpress</a> 

                <script type='text/javascript'>
            function init_map() {
                var myOptions = {zoom: 17, center: new google.maps.LatLng(-17.8331914, 31.05178360000002), mapTypeId: google.maps.MapTypeId.HYBRID};
                map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
                marker = new google.maps.Marker({map: map, position: new google.maps.LatLng(-17.8331914, 31.05178360000002)});
                infowindow = new google.maps.InfoWindow({content: '<strong>Pure Plus Solutions</strong><br>Merchant House Robson Manyika Avenue<br> Harare<br>'});
                google.maps.event.addListener(marker, 'click', function () {
                    infowindow.open(map, marker);
                });
                infowindow.open(map, marker);
            }
            google.maps.event.addDomListener(window, 'load', init_map);


                </script>

            </div>

        </section>
        <br/>

        <!-- section start -->
        <!-- ================ -->
        <section class="section pv-40 parallax background-img-1  light-translucent-bg" style="background-position:50% 60%;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="call-to-action text-center">
                            <div class="row">
                                <div class="col-sm-8 col-sm-offset-2">


                                    <h2 class="title">Subscribe to Our Newsletter</h2>
                                    <?php
                                    global $newsResults;
                                    echo $newsResults;
                                    ?>
                                    <div class="separator"></div>
                                    <form method="post" action="newSubcriber.php" class="form-inline margin-clear">
                                        <div class="form-group has-feedback">
                                            <label>Email address</label>
                                            <input type="email" class="form-control" id="subscribe34" placeholder="Enter email" name="subscribe34" required/>
                                            <i class="fa fa-envelope form-control-feedback"></i>
                                        </div>
                                        <button type="submit" class="btn btn-gray-transparent btn-animated margin-clear" onclick="document.getElementById('id01').style.display = 'block'" >Submit <i class="fa fa-send"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>




        <!-- section end -->
        <!-- section end -->
       
        <!-- footer end -->


        <!-- page-wrapper end -->

        <!-- Jquery and Bootstap core js files -->
        <script type="text/javascript" src="./bootstrap/js/jquery.min.js"></script>
        <script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
        <!-- Modernizr javascript -->
        <script type="text/javascript" src="./bootstrap/js/modernizr.js"></script>
        <!-- jQuery Revolution Slider  -->
        <script type="text/javascript" src="./bootstrap/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="./bootstrap/js/jquery.themepunch.revolution.min.js"></script>
        <!-- Isotope javascript -->
        <script type="text/javascript" src="./bootstrap/js/isotope.pkgd.min.js"></script>
        <!-- Magnific Popup javascript -->
        <script type="text/javascript" src="./bootstrap/js/jquery.magnific-popup.min.js"></script>
        <!-- Appear javascript -->
        <script type="text/javascript" src="./bootstrap/js/jquery.waypoints.min.js"></script>
        <!-- Count To javascript -->
        <script type="text/javascript" src="./bootstrap/js/jquery.countTo.js"></script>
        <!-- Parallax javascript -->
        <script src="./bootstrap/js/jquery.parallax-1.1.3.js"></script>
        <!-- Contact form -->
        <script src="./bootstrap/js/jquery.validate.js"></script>
        <!-- Morphext -->
        <script type="text/javascript" src="./bootstrap/js/morphext.min.js"></script>
        <!-- Background Video -->
        <script src="./bootstrap/js/jquery.vide.js"></script>
        <!-- Owl carousel javascript -->
        <script type="text/javascript" src="./bootstrap/js/owl.carousel.js"></script>
        <!-- SmoothScroll javascript -->
        <script type="text/javascript" src="./bootstrap/js/jquery.browser.js"></script>
        <script type="text/javascript" src="./bootstrap/js/SmoothScroll.js"></script>
        <!-- Initialization of Plugins -->
        <script type="text/javascript" src="./bootstrap/js/template.js"></script>
        <!-- Custom Scripts -->
        <script type="text/javascript" src="./bootstrap/js/custom.js"></script>
        <script type="text/javascript" src="./bootstrap/js/domains.js"></script>
        <script type="text/javascript" src="./bootstrap/js/quickmail.js"></script>
        <script type="text/javascript" src="./bootstrap/js/quotation.js"></script>
        <script type="text/javascript" src="./bootstrap/js/sweetalert-dev.js"></script>

    </body>


</html>
