$(function(){
            
     
$(".send-mail").click(function() 
{ 
var email = document.getElementById('email').value;;
var name=document.getElementById('name').value;
var message=document.getElementById('message').value;
if(email!=''||  name!=''||message!='')
{
	$.post( "http://localhost/agroupmyapps/support/quickmail.php",
	{email:email,name:name,message:message},
        function(data)
	{
        
         if(data.toString()=="success")
                         {
                          swal("Good Job", "Message delivered", "success");   
                         }
                         else
                         {
                          swal("Response", "Invalid information.Please try again", "error");
                            }
        
	//$(".response-area").html(html).show();
        document.getElementById('message').value="";
	}
	);
}
else
{
    swal("Oops...", "Fill all fields .Try again!", "error");
 
	
	}return false;    
});
   
   $('#subscriber-submit').click(function(){
   // $('.newletter-response').html("Invalid email.Please try again!");
    var email=document.getElementById('subscriber-email').value;
    if(email!='')
    {
      $.post('support/newletter.php',
      {email:email},
      function(data){
          $('.newletter-response').html(""+data);
      });  
    }
    else
    {$('.newletter-response').html("Invalid email.Please try again!");
    }
});

$(function () { $("[data-toggle='tooltip']").tooltip(); });
        });


