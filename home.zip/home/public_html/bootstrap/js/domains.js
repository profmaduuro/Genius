$(function(){
            
     
$("#offer").click(function() 
{ 
var email = document.getElementById('email').value;;
var offer=document.getElementById('user-offer').value;
var offer_min=document.getElementById('offer-min').value;
var id=document.getElementById('domain').value;
if(email!=''||  offer!='')
{
	$.post( "support/domain.php",
	{email:email,offer:offer,id:id,offer_min:offer_min},
        function(html)
	{
        $('.response-area').html("<p class='text-warning'>Sending message......</p>");
	$(".response-area").html(html).show();
	}
	);
}
else
{
 $('.response-area').html('<div class="alert alert-danger">'+ 
             '<a href="#" class="close" data-dismiss="alert"> &times; </a>'+
                 '<strong><span class="fa fa-warning fa-1x"></span></strong>Fill all fields .Try again!</div>');
	
	}return false;    
});
  
        });


