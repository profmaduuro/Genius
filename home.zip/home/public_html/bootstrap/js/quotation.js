$(function(){
    
    



       $(".quotation").click(function(){
                        var need=document.getElementById("need").value;
                        var done=document.getElementById("done").value;
                        var skills=document.getElementById("skills").value;
                        var budget=document.getElementById("budget").value;
                        var email=document.getElementById("email").value;
                        if (email!="")
{
                        $.post("http://localhost/agroupmyapps/support/quotation.php",
                        {need:need,
                         done:done,
                         skills:skills,
                         budget:budget,
                         email:email},
                     function(data,status)
                     {
                         if(data.toString()=="success")
                         {
                          swal("Good Job", "Message delivered", "success");   
                         }
                         else
                         {
                          swal("Response", "Invalid information.Please try again", "error");
                            }
                         
                     });
                 }
                 else
                        {
 
                            swal("Oops...", "Make sure all fields are filled and try again!", "error");
                        }
                    });
 


});
    


