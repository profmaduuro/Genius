<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Homes.zw| About</title>

        <script type="text/javascript">
//<![CDATA[
            try {
                if (!window.CloudFlare) {
                    var CloudFlare = [{verbose: 0, p: 0, byc: 0, owlid: "cf", bag2: 1, mirage2: 0, oracle: 0, paths: {cloudflare: "/cdn-cgi/nexp/dok3v=1613a3a185/"}, atok: "dab54c9f2269d3daa19f1ddfe5efec5f", petok: "57de20e737dfdb4f5e8193e5e7d2240d629fc459-1465050533-1800", zone: "myapps.co.zw", rocket: "0", apps: {"vuukle": {"domain_id": "10690396", "account_id": "65983", "comments-location": "left"}, "abetterbrowser": {"ie": "6"}}, sha2test: 0}];
                    !function (a, b) {
                        a = document.createElement("script"), b = document.getElementsByTagName("script")[0], a.async = !0, a.src = "ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3de982913d31/cloudflare.min.js", b.parentNode.insertBefore(a, b)
                    }()
                }
            } catch (e) {
            }
            ;
//]]>
        </script>
        <link rel="shortcut icon" href="images/icon.ico">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=PT+Serif' rel='stylesheet' type='text/css'>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="bootstrap/fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="bootstrap/fonts/fontello/css/fontello.css" rel="stylesheet">
        <link href="bootstrap/fonts/fontello/css/fontello.css" rel="stylesheet">
        <link href="bootstrap/css/magnific-popup.css" rel="stylesheet">
        <link href="bootstrap/css/settings.css" rel="stylesheet">
        <link href="bootstrap/css/animations.css" rel="stylesheet">
        <link href="bootstrap/css/owl.carousel.css" rel="stylesheet">
        <link href="bootstrap/css/owl.transitions.css" rel="stylesheet">
        <link href="bootstrap/css/hover-min.css" rel="stylesheet">
        <link href="bootstrap/css/sweetalert.css" rel="stylesheet">
        <link href="bootstrap/css/w3.css" rel="stylesheet">
        <link href="bootstrap/css/style.css" rel="stylesheet" >
        <link href="bootstrap/css/light_blue.css" rel="stylesheet">

        <link href="bootstrap/css/custom.css" rel="stylesheet">
    </head>
    <body>
        
        <div style="background-image: url('_images/google.jpg' )">
            <!-- ================ -->
            <div class="breadcrumb-container">
                <div class="container">
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home pr-10"></i><a class="link-dark" href="./maddymotion.html">Home</a></li>
                        <li class="active">About Us</li>
                    </ol>
                </div>
            </div>

      
        <br/>
        <!-- ============== About and Service section ============== -->
        <div class="second-section2">
            <div class="container about-section">
                <div class="row">

                    <div class="col-lg-12 col-md-12 col-sm-12 ">
                        <div data-animation-effect="fadeInDownSmall" data-effect-delay="200">
                          
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"><span class="fa fa-users"></span> Who we are</h3>
                            <div class="separator clearfix"></div>
                            <p class="text-justify">
                                MaddyMotion is a Zimbabwean Organisation started by a young AFRICAN computer engineer , it is mainly motivated by the developing of businesses in the african continent and by that its part of the <b>AfricaDevelop</b> initiative. The company is is ther to provide a wide range of solutions for every small african company which is trying to make itself big.
                            <br/><br/>
                            MaddyMotion, as a business concept, was premeditated when one of the directors had finished his diploma in computer engineering, so he ventured into motion graphics at home and he became good at it, later on he was accepted at <a href="http://www.muzindahub.co.zw" title="muzinda hub site"><b>Muzinda Hub</b></a> for a web development certification and became a web developer. With the faith of "anything is possible", he named his productions after maddymotions, and then later rebranded it to MaddyMotion Solutions.
                              <br/><br/>
                              MaddyMotion Solutions is self driven by young confident and energetic developers with the aim of making a change in the world of business and to move the <b>AfricaDevelop</b> initiative,it is a fast growing company providing businesses with the best if motion graphics, software development and web development,with the stiff industry MaddyMotion is still standing its ground with the best solutions it offers.

                            </p>
                        </div>
                    </div>
                    <!-- /.col-lg-4 col-md-4 col-sm-4 -->
                    <div class="col-lg-12 col-md-12 col-sm-12 service service_heading">
                        
                        <div class="row">

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="business2 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s">
                                    <h4 ><span class="fa fa-eye fa-2x"></span> Our Vision</h4>
                                    <p class="news6">To be acknowledged as the best , create a new era of technology in africa, give customers and businesses the power to accomplish their goals, and in doing so help to build stronger economies across the globe with our solutions.</p>
                                </div>
                                <!-- /.business -->
                            </div>
                            <!-- /.col-lg-4 col-md-4 col-sm-4 -->

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="business2 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">
                                    <h4 class="newse2"> <span class="fa fa-road fa-2x"></span>Our Mission</h4>
                                    <p class="news6">To have a wide range of content on the market for your businnes from text to visuals.</p>
                                </div>
                                <!-- /.business -->
                            </div>
                            <!-- /.col-lg-4 col-md-4 col-sm-4 -->

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="business2 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                                    <h4 class="newse2"><span class="fa fa-globe fa-2x "></span> Our Aim</h4>
                                    <p class="news6">
                                       We aim to Design Develop and Innovate
                                    </p>
                                </div>
                                <!-- /.business -->
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="business2 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                                    <h4 class="newse2"><span class="fa fa-heartbeat fa-2x "></span> Our Core Value</h4>
                                    <p class="news6">
                                        Our actions and behavior are established on integrity, transparency, accountability, reliability, excellence, simplicity as well as effective and efficient performance. 
                                    </p>
                                </div>
                                <!-- /.business -->
                            </div>

                            <!-- /.col-lg-4 col-md-4 col-sm-4 -->
                        </div>
                        <!-- /.row -->
                        <!--row-->
    

                    </div>
                   
                    
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <hr/>

        <div class="our-clients3">
            <div class="container wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.4s">
                <!--start of team-->
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
                        <h2 class="text-center">OUR TEAM</h2>
                    </div>
                </div>
                <!--container-->
            </div>
            <!--row-->
        </div>

        <!--ourclients-->
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-3 col-xs-12 text-center">
                    <div class="pv-30 ph-20 feature-box bordered shadow text-center object-non-visible" data-animation-effect="fadeInDownSmall" data-effect-delay="200">
                        <img src="_images/taffy.jpg" alt="team" class="img-circle img-responsive img center-block wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.4s" width="150" height="100">
                        <div class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s"><br/>
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">Tafadzwa Maduuro</h3>

                            <p>Motion Graphics/Web Developer</p>
                            <div class="separator clearfix"></div>
                            <p class="style">
                                Get In touch
                            </p>
                        </div>
                        <div class="link-box2 mleft">
                            <a href="http://www.facebook.com/tmaduuro"><i class="fa fa-facebook icon default-bg small circle-head"></i></a>
                            <a href="skype:fzinyowera?call"><i class="fa fa-skype icon default-bg small circle"></i></a>
                            <a href="http://www.linkedin.com/profmaduuro"><i class="fa fa-linkedin icon default-bg small default-hovered circle-head"></i></a>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-12 text-center">
                    <div class="pv-30 ph-20 feature-box bordered shadow text-center object-non-visible" data-animation-effect="fadeInDownSmall" data-effect-delay="200">
                        <img src="_images/cloud.jpg" alt="team" class="img-circle img-responsive img center-block wow fadeIn" data-wow-duration="1s" data-wow-delay="0.4s" width="200" height="200">
                        <div class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s"><br/>
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">Silent Dzambo</h3>

                            <p>Senior Software Developer</p>
                            <div class="separator clearfix"></div>
                            <p class="style">
                                Get In touch
                            </p>
                        </div>
                        <div class="link-box2 mleft">
                            <a href="http://www.facebook.com/sdzambo"><i class="fa fa-facebook icon default-bg small circle-head"></i></a>
                            <a href="http://www.skype.com/sdzambo"><i class="fa fa-skype icon default-bg small circle"></i></a>
                            <a href="http://www.linkedin.com"><i class="fa fa-linkedin icon default-bg small default-hovered circle-head"></i></a>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-12 text-center">
                    <div class="pv-30 ph-20 feature-box bordered shadow text-center object-non-visible" data-animation-effect="fadeInDownSmall" data-effect-delay="200">
                        <img src="_images/tau.jpg" alt="team" class="img-circle img-responsive img center-block wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.4s" width="150" height="100">
                        <div class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s"><br/>
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">Taurai Moyo</h3>

                            <p>Software Developer/Consultant</p>
                            <div class="separator clearfix"></div>
                            <p class="style">
                                Get In touch
                            </p>
                        </div>
                        <div class="link-box2 mleft">
                            <a href="http://www.facebook.com/TMoyo"><i class="fa fa-facebook icon default-bg small circle-head"></i></a>
                            <a href="http://www.skype.com/tmoyo"><i class="fa fa-skype icon default-bg small circle"></i></a>
                            <a href="http://www.linkedin.com"><i class="fa fa-linkedin icon default-bg small default-hovered circle-head"></i></a>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-12 text-center">
                      <div class="pv-30 ph-20 feature-box bordered shadow text-center object-non-visible" data-animation-effect="fadeInDownSmall" data-effect-delay="200">
                          <img src="_images/joji.jpg" alt="team" class="img-circle img-responsive img center-block wow fadeIn" data-wow-duration="1s" data-wow-delay="0.4s" width="150" height="100">
                        <div class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.8s"><br/>
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">George Muranganwa</h3>

                            <p>Application Developer/Web</p>
                            <div class="separator clearfix"></div>
                            <p class="style">
                                Get In touch
                            </p>
                        </div>
                        <div class="link-box2 mleft">
                            <a href=""><i class="fa fa-facebook icon default-bg small circle-head"></i></a>
                            <a href="http://www.skype.com/george93"><i class="fa fa-skype icon default-bg small circle"></i></a>
                            <a href="http://www.linkedin.com/georgemuranganwa"><i class="fa fa-linkedin icon default-bg small default-hovered circle-head"></i></a>

                        </div>
                    </div>
                </div>  
            </div>
        </div>
        <hr/>    
        <br/>





        </div>
        
        <!-- Jquery and Bootstap core js files -->
        <script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- Modernizr javascript -->
        <script type="text/javascript" src="bootstrap/js/modernizr.js"></script>
        <!-- jQuery Revolution Slider  -->
        <script type="text/javascript" src="bootstrap/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/jquery.themepunch.revolution.min.js"></script>
        <!-- Isotope javascript -->
        <script type="text/javascript" src="bootstrap/js/isotope.pkgd.min.js"></script>
        <!-- Magnific Popup javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.magnific-popup.min.js"></script>
        <!-- Appear javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.waypoints.min.js"></script>
        <!-- Count To javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.countTo.js"></script>
        <!-- Parallax javascript -->
        <script src="bootstrap/js/jquery.parallax-1.1.3.js"></script>
        <!-- Contact form -->
        <script src="bootstrap/js/jquery.validate.js"></script>
        <!-- Morphext -->
        <script type="text/javascript" src="bootstrap/js/morphext.min.js"></script>
        <!-- Background Video -->
        <script src="bootstrap/js/jquery.vide.js"></script>
        <!-- Owl carousel javascript -->
        <script type="text/javascript" src="bootstrap/js/owl.carousel.js"></script>
        <!-- SmoothScroll javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.browser.js"></script>
        <script type="text/javascript" src="bootstrap/js/SmoothScroll.js"></script>
        <!-- Initialization of Plugins -->
        <script type="text/javascript" src="bootstrap/js/template.js"></script>
        <!-- Custom Scripts -->
        <script type="text/javascript" src="bootstrap/js/custom.js"></script>
        <script type="text/javascript" src="bootstrap/js/domains.js"></script>
        <script type="text/javascript" src="bootstrap/js/quickmail.js"></script>
        <script type="text/javascript" src="bootstrap/js/quotation.js"></script>
        <script type="text/javascript" src="bootstrap/js/sweetalert-dev.js"></script>
        <script type="text/javascript">/* <![CDATA[ */(function (d, s, a, i, j, r, l, m, t) {
                try {
                    l = d.getElementsByTagName('a');
                    t = d.createElement('textarea');
                    for (i = 0; l.length - i; i++) {
                        try {
                            a = l[i].href;
                            s = a.indexOf('/cdn-cgi/l/email-protection');
                            m = a.length;
                            if (a && s > -1 && m > 28) {
                                j = 28 + s;
                                s = '';
                                if (j < m) {
                                    r = '0x' + a.substr(j, 2) | 0;
                                    for (j += 2; j < m && a.charAt(j) != 'X'; j += 2)
                                        s += '%' + ('0' + ('0x' + a.substr(j, 2) ^ r).toString(16)).slice(-2);
                                    j++;
                                    s = decodeURIComponent(s) + a.substr(j, m - j)
                                }
                                t.innerHTML = s.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                                l[i].href = 'mailto:' + t.value
                            }
                        } catch (e) {
                        }
                    }
                } catch (e) {
                }
            })(document);/* ]]> */
        </script>
        <script src="js/jquery1.11.3.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="vendors/bxslider/js/jquery.bxslider.min.js"></script>
        <!--revolution-slider-->
        <script src="vendors/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script src="vendors/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script src="vendors/OwlCarousel/owl-carousel/owl.carousel.js"></script>
        <script src="vendors/wow/wow.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/index.js"></script>
        <script type="text/javascript" src="http://adapi.ragapa.com/v1/rgp-location-layout-html?id=telco.co.zw-011515"></script>
        <script type="text/javascript" src="http://adapi.ragapa.com/v1/rgp-location-layout?id=telco.co.zw-011515"></script>
     </body>
</html>
