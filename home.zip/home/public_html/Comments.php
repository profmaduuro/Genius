<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Homes.zw| About</title>

        <script type="text/javascript">
//<![CDATA[
            try {
                if (!window.CloudFlare) {
                    var CloudFlare = [{verbose: 0, p: 0, byc: 0, owlid: "cf", bag2: 1, mirage2: 0, oracle: 0, paths: {cloudflare: "/cdn-cgi/nexp/dok3v=1613a3a185/"}, atok: "dab54c9f2269d3daa19f1ddfe5efec5f", petok: "57de20e737dfdb4f5e8193e5e7d2240d629fc459-1465050533-1800", zone: "myapps.co.zw", rocket: "0", apps: {"vuukle": {"domain_id": "10690396", "account_id": "65983", "comments-location": "left"}, "abetterbrowser": {"ie": "6"}}, sha2test: 0}];
                    !function (a, b) {
                        a = document.createElement("script"), b = document.getElementsByTagName("script")[0], a.async = !0, a.src = "ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3de982913d31/cloudflare.min.js", b.parentNode.insertBefore(a, b)
                    }()
                }
            } catch (e) {
            }
            ;
//]]>
        </script>
        <link rel="shortcut icon" href="images/icon.ico">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:700,400,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=PT+Serif' rel='stylesheet' type='text/css'>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="bootstrap/fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="bootstrap/fonts/fontello/css/fontello.css" rel="stylesheet">
        <link href="bootstrap/fonts/fontello/css/fontello.css" rel="stylesheet">
        <link href="bootstrap/css/magnific-popup.css" rel="stylesheet">
        <link href="bootstrap/css/settings.css" rel="stylesheet">
        <link href="bootstrap/css/animations.css" rel="stylesheet">
        <link href="bootstrap/css/owl.carousel.css" rel="stylesheet">
        <link href="bootstrap/css/owl.transitions.css" rel="stylesheet">
        <link href="bootstrap/css/hover-min.css" rel="stylesheet">
        <link href="bootstrap/css/sweetalert.css" rel="stylesheet">
        <link href="bootstrap/css/w3.css" rel="stylesheet">
        <link href="bootstrap/css/style.css" rel="stylesheet" >
        <link href="bootstrap/css/light_blue.css" rel="stylesheet">

        <link href="bootstrap/css/custom.css" rel="stylesheet">
    </head>
    <body>
        
        <div style="background-image: url('_images/google.jpg' )">
            <!-- ================ -->
            <div class="breadcrumb-container">
                <div class="container">
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home pr-10"></i><a class="link-dark" href="index.html">Home</a></li>
                        <li class="active">Comments</li>
                    </ol>
                </div>
            </div>

      
        <br/>
        <!-- ============== About and Service section ============== -->
        <div class="second-section2">
            <div class="container about-section">
                <div class="row">

                    <div class="col-lg-12 col-md-12 col-sm-12 ">
                        <div data-animation-effect="fadeInDownSmall" data-effect-delay="200">
                          
                          
                    </div>
                    <!-- /.col-lg-4 col-md-4 col-sm-4 -->
                    <div class="col-lg-12 col-md-12 col-sm-12 service service_heading">
                        
                        <div class="row">

                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h2 class="text-center">Comments made</h2>
                                <table class="table table-bordered table stripped">
                                    <thead>
                                    <th>Full name</th>
                                      <th>Email Address</th>
                                        <th>Comment Made</th>
                                </thead>
                                <tbody>
                                   <?php
                                   include './config/db.php';
                                                    $rec = "SELECT * FROM comments";
                                                    $formdata = mysqli_query($connect, $rec);
                                                    while ($row = mysqli_fetch_array($formdata)) {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $row['name']; ?></td>
                                                            <td><?php echo $row['email']; ?></td>
                                                            <td><?php echo $row['comment']; ?></td>
                                                           

                                                        </tr>
                                                    <?php } ?> 
                                </tbody>
                                </table>
                            </div>
                            <!-- /.col-lg-4 col-md-4 col-sm-4 -->

                                <!-- /.business -->
                            </div>
                          
                            <!-- /.col-lg-4 col-md-4 col-sm-4 -->
                        </div>
                        <!-- /.row -->
                        <!--row-->
    

                    </div>
                   
                    
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <hr/
        <hr/>    
        <br/>





        </div>
        
        <!-- Jquery and Bootstap core js files -->
        <script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- Modernizr javascript -->
        <script type="text/javascript" src="bootstrap/js/modernizr.js"></script>
        <!-- jQuery Revolution Slider  -->
        <script type="text/javascript" src="bootstrap/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/jquery.themepunch.revolution.min.js"></script>
        <!-- Isotope javascript -->
        <script type="text/javascript" src="bootstrap/js/isotope.pkgd.min.js"></script>
        <!-- Magnific Popup javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.magnific-popup.min.js"></script>
        <!-- Appear javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.waypoints.min.js"></script>
        <!-- Count To javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.countTo.js"></script>
        <!-- Parallax javascript -->
        <script src="bootstrap/js/jquery.parallax-1.1.3.js"></script>
        <!-- Contact form -->
        <script src="bootstrap/js/jquery.validate.js"></script>
        <!-- Morphext -->
        <script type="text/javascript" src="bootstrap/js/morphext.min.js"></script>
        <!-- Background Video -->
        <script src="bootstrap/js/jquery.vide.js"></script>
        <!-- Owl carousel javascript -->
        <script type="text/javascript" src="bootstrap/js/owl.carousel.js"></script>
        <!-- SmoothScroll javascript -->
        <script type="text/javascript" src="bootstrap/js/jquery.browser.js"></script>
        <script type="text/javascript" src="bootstrap/js/SmoothScroll.js"></script>
        <!-- Initialization of Plugins -->
        <script type="text/javascript" src="bootstrap/js/template.js"></script>
        <!-- Custom Scripts -->
        <script type="text/javascript" src="bootstrap/js/custom.js"></script>
        <script type="text/javascript" src="bootstrap/js/domains.js"></script>
        <script type="text/javascript" src="bootstrap/js/quickmail.js"></script>
        <script type="text/javascript" src="bootstrap/js/quotation.js"></script>
        <script type="text/javascript" src="bootstrap/js/sweetalert-dev.js"></script>
        <script type="text/javascript">/* <![CDATA[ */(function (d, s, a, i, j, r, l, m, t) {
                try {
                    l = d.getElementsByTagName('a');
                    t = d.createElement('textarea');
                    for (i = 0; l.length - i; i++) {
                        try {
                            a = l[i].href;
                            s = a.indexOf('/cdn-cgi/l/email-protection');
                            m = a.length;
                            if (a && s > -1 && m > 28) {
                                j = 28 + s;
                                s = '';
                                if (j < m) {
                                    r = '0x' + a.substr(j, 2) | 0;
                                    for (j += 2; j < m && a.charAt(j) != 'X'; j += 2)
                                        s += '%' + ('0' + ('0x' + a.substr(j, 2) ^ r).toString(16)).slice(-2);
                                    j++;
                                    s = decodeURIComponent(s) + a.substr(j, m - j)
                                }
                                t.innerHTML = s.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                                l[i].href = 'mailto:' + t.value
                            }
                        } catch (e) {
                        }
                    }
                } catch (e) {
                }
            })(document);/* ]]> */
        </script>
        <script src="js/jquery1.11.3.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="vendors/bxslider/js/jquery.bxslider.min.js"></script>
        <!--revolution-slider-->
        <script src="vendors/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script src="vendors/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script src="vendors/OwlCarousel/owl-carousel/owl.carousel.js"></script>
        <script src="vendors/wow/wow.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/index.js"></script>
        <script type="text/javascript" src="http://adapi.ragapa.com/v1/rgp-location-layout-html?id=telco.co.zw-011515"></script>
        <script type="text/javascript" src="http://adapi.ragapa.com/v1/rgp-location-layout?id=telco.co.zw-011515"></script>
     
        </div>
        </body>
</html>
